Refer : https://docs.google.com/document/d/1EmHlk8TZM6B2os8nQx87DPkqHvPMKuTx1ycUQ14mBAI/edit?usp=sharing
